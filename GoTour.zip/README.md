# GoTour
Aplicación web para que establecer una conexión entre usuarios que quieran conocer un lugar y otros que quieran hacer de guías turísticos.

# Recursos
icono de lupa: https://commons.wikimedia.org/wiki/File:Magnifying_glass_icon_mgx2.svg
imagen del usuario: https://commons.wikimedia.org/wiki/File:Space_Marine_Cosplay_-_MCM_Comic_Con_2016_(27122904700).jpg