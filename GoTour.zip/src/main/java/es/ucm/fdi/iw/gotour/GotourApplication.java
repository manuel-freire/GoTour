package es.ucm.fdi.iw.gotour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GotourApplication {

	public static void main(String[] args) {
		SpringApplication.run(GotourApplication.class, args);
	}

}
